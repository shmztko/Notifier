#!/bin/sh
java -cp ./*:./lib/*:./lib/gdata/*:./lib/gdata/api/*:./lib/rome/*:./lib/skype/*: -Djava.library.path=./lib/skype org.takewo.main.StartPoint