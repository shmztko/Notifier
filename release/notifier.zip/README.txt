ReadMe

This project includes following libraries.

 - Skype4java(http://developer.skype.com/wiki/Java_API).
 - The Google Data Java client library.
 - Rome, Atom/RSS Java utilities.
 - JDOM 1.1.1
 - Google Guava Library
 - Servlet API
 - JavaMail API
 - JavaBeans Activation Framework